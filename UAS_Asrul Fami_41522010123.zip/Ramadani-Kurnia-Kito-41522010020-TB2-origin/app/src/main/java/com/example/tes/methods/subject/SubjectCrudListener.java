package com.example.tes.methods.subject;

public interface SubjectCrudListener {
    void onSubjectListUpdate(boolean isUpdate);
}
