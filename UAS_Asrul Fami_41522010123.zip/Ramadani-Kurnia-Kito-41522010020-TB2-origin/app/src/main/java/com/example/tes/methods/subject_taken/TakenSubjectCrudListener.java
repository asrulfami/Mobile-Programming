package com.example.tes.methods.subject_taken;

public interface TakenSubjectCrudListener {
    void onTakenSubjectUpdated(boolean isUpdated);
}
