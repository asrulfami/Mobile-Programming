package com.example.tes.methods.student;

public interface StudentCrudListener {
    void onStudentListUpdate(boolean isUpdated);
}
